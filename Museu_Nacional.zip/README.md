# Museu Nacional
  Fictitious project of an institutional web site called Museo Nacional.
 
### OBJECTIVE
>Exercise knowledge acquired during the study of HTML5, CSS3.

### TECNOLOGIES

> HTML5,
> CSS3. 

### SCREEN

Home |
---|
![print_home](https://user-images.githubusercontent.com/45773955/236712044-acb48373-4cc8-430a-b9bf-b3b85ef5bf4a.png)
